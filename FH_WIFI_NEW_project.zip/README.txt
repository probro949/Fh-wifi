FH WIFI Android project
App name: FH WIFI
Website: https://fh-wlan.vercel.app/
Instagram: https://www.instagram.com/vvvu._4/
This is a fresh app identity (com.fhwifi.app), so it can install separately from older builds.
Build with: gradle assembleDebug
